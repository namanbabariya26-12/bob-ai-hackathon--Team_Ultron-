"""Download optional public research data. Nothing downloaded here is treated as Indian operational ground truth."""
from pathlib import Path
from urllib.request import urlretrieve

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'data'/'external'; out.mkdir(parents=True,exist_ok=True)
URL='https://phm-datasets.s3.amazonaws.com/NASA/6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip'
target=out/'cmapss.zip'
print('Downloading NASA C-MAPSS research dataset to', target)
urlretrieve(URL,target)
print('Downloaded. Review license/provenance before use. This repository does not treat it as operational ground truth.')
