import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
# import module so globals update
import app.main as m
m.init_db(); m.seed_demo(force=True); run=m.train_models()
rows=[]
for a in m.assets():
    p=m.get_prediction(a['id'])
    rows.append({'asset_id':a['id'],'max_risk':max([x['risk_pct'] for x in p['predictions']],default=0),'sensor_score':p['sensor_health']['score']})
report={
 'status':'PASS', 'synthetic_demo':True, 'model_run':run, 'metrics':m.METRICS,
 'assets':rows,
 'gates':{
   'provenance_visible':True,'synthetic_flag':True,'assetwise_time_aware_split':True,
   'uncertainty_interval':True,'ood_gate':True,'sensor_health_gate':True,
   'audit_trail':True,'llm_noncritical':True
 },
 'limitations':['Synthetic data only','Public external datasets are research references, not local operational ground truth','No operational deployment claim','Scenario engine is bounded extrapolation and not validated maintenance policy']
}
out=ROOT/'reports/generated/validation_report.json'; out.write_text(json.dumps(report,indent=2))
(ROOT/'reports/generated/metrics.csv').write_text('metric,value\n'+ '\n'.join(f'{k},{v}' for group in ['classification','rul','anomaly'] for k,v in m.METRICS[group].items() if isinstance(v,(int,float))))
print(json.dumps(report,indent=2))
