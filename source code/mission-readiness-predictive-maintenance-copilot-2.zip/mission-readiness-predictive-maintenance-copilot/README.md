# Mission Readiness & Predictive Maintenance Copilot

**Safety-critical predictive-maintenance and fleet-readiness analytics prototype.**

> **DEMONSTRATION DATA — NOT OPERATIONAL DATA**

This prototype deliberately excludes weapons targeting, target selection, attack planning, combat optimization, tactical mission planning, and lethal-action recommendations. It focuses on equipment health, reliability, maintenance prioritization, uncertainty, provenance and auditability.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://localhost:8000

Or:

```bash
docker compose up --build
```

## What is implemented

### IBM Bob AI integration

The dashboard now includes a direct IBM Bob HTTPS REST API integration. The backend calls Bob's OpenAI-compatible inference endpoint (`/inference/v1/chat/completions`) directly with `httpx`; **Bob Shell/CLI is not installed, invoked, or required**. The current fleet/prediction/sensor context is sent as the model prompt, while the Bob API key remains server-side.

The integration also probes Bob's `/inference/v1/model/info` endpoint for connectivity/model discovery. Configure an IBM Bob Inference API key in `BOB_API_KEY`. For Bob 2.x, provide `BOB_INSTANCE_ID` if your subscription requires the `x-instance-id` header; a General key may also require `BOB_TEAM_ID`.

### Live, non-fixed readings

The UI now auto-refreshes, accepts individual or batch sensor readings, range-checks them, and recalculates sensor health, model predictions, readiness and maintenance age from the current database. The old hard-coded asset maintenance score has been removed.

- Deterministic synthetic fleet generator (seeded)
- Sensor-health checks: missing, flatline, spike, range, drift and sampling irregularity
- Feature engineering: rolling statistics, EWMA/CUSUM-like trend features, correlations and maintenance-gap features
- Time-aware, asset-wise model evaluation
- Statistical/EWMA anomaly baseline + Isolation Forest
- Calibrated failure-risk classifier (Random Forest + probability calibration)
- RUL estimator (Random Forest regression) with conformal-style residual interval
- Mahalanobis-style OOD score
- Transparent readiness decomposition
- Explainability via SHAP when available, with permutation fallback
- Maintenance-record rule-based NLP extraction that never invents measurements
- Transparent maintenance prioritization
- What-if scenario engine
- Data provenance registry
- Immutable prediction/audit records in SQLite
- FastAPI API
- Responsive single-page engineering dashboard
- Model cards, domain-shift report, evidence ledger, validation report and self-critique artifacts
- Security controls suitable for a local prototype: validation, API-key protected ingest/admin endpoints, security headers, audit log and no hard-coded production secrets

## Data policy

The demo uses synthetic data and is visibly labelled as such. Public datasets such as NASA C-MAPSS and NASA IMS are documented as external validation/research sources, not as Indian operational ground truth. See `docs/research/domain-shift-report.md`.

## Demo credentials

- UI is read-only/demo by default.
- Protected demo operations use `X-API-Key: demo-admin-key`.
- Change this value before any non-demo deployment.

## Evaluation

Run:

```bash
python scripts/run_demo.py
pytest -q
```

The evaluation writes `reports/generated/validation_report.json` and `reports/generated/metrics.csv`.

## Important limitation

This is a competition prototype, not a deployment-ready maintenance authority. Predictions are model estimates and require validation against representative local asset data, maintenance policy, sensor configuration and operating conditions before any operational use.

## IBM Bob setup — direct API, no Bob CLI

1. Copy `.env.example` to `.env`.
2. Put your Bob **Inference API key** in `BOB_API_KEY`.
3. Keep `BOB_BASE_URL=https://api.us-east.bob.ibm.com/inference/v1` unless your Bob subscription uses another documented regional endpoint.
4. Set `BOB_MODEL=premium` or another model exposed by your subscription.
5. If Bob requires it, set `BOB_INSTANCE_ID`; for a General API key, also set `BOB_TEAM_ID`.
6. Set `ADMIN_API_KEY` to a private value used for live sensor ingestion.
7. Start the application with `python start.py`.
8. Open `http://127.0.0.1:8000` and select **AI Copilot**.

**No Bob Shell, Bob CLI, batch file, or subprocess is used.** The server talks to Bob over HTTPS using the OpenAI-compatible chat-completions API. The API key stays server-side and is never embedded in HTML or JavaScript.

## New API routes

- `GET /api/v1/copilot/status` — checks Bob connectivity without exposing the key.
- `POST /api/v1/copilot/chat` — sends a maintenance/readiness question plus current telemetry context to IBM Bob.
- `GET /api/v1/live/summary` — current reading freshness and Bob status.
- `GET /api/v1/sensors` — available sensors and valid ranges.
- `POST /api/v1/ingest/sensor` — authenticated single-reading ingestion.
- `POST /api/v1/ingest/batch` — authenticated batch ingestion.

### Example live reading

```text
POST /api/v1/ingest/sensor
X-API-Key: <your ADMIN_API_KEY>
Content-Type: application/json

{
  "sensor_id": "ASSET-002-C1-vibration_rms",
  "ts": "2026-09-15T16:30:00Z",
  "value": 1.2
}
```

Predictions are still estimates. Real operational deployment requires representative historical data, labels, sensor calibration and maintenance-policy validation.
