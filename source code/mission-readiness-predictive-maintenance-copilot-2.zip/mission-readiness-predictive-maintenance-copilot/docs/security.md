# Security Model

- Inputs are validated with Pydantic.
- Ingest requires a demo API key.
- Production secrets are environment variables; `.env` is ignored.
- CORS is restricted to local demo origins.
- Audit records are append-only through the application interface.
- The frontend never contains secrets.
- Synthetic data is visibly labelled.
- Raw maintenance notes are not sent to an LLM by the prototype.
- Dependency scanning should be run in CI (`pip-audit`) before deployment.
- HTTPS/HSTS should be enforced by the production reverse proxy.
- This prototype uses SQLite for portability; a production deployment should use PostgreSQL/TimescaleDB with encrypted storage and centralized identity.
