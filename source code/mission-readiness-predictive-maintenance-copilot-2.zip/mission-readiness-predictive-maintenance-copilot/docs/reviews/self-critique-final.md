# Final Self-Critique

## Assumptions
- Synthetic degradation curves are plausible but not physical validation.
- Failure-risk labels are generated from synthetic lifecycle position.
- RUL is measured in synthetic operating-cycle-derived hours.
- Scenario risk extrapolation is a bounded demonstration, not a validated maintenance policy.

## False-positive risks
- Sensor spikes may resemble degradation.
- Maintenance text can be ambiguous.
- Distribution shifts can raise risk estimates spuriously.

## False-negative risks
- Slow degradation outside training patterns.
- Unmeasured failure modes.
- Simultaneous sensor and component faults.

## Leakage review
- RUL and failure labels are removed from model features.
- Asset identifiers are removed.
- Training/testing are ordered; no random mixing of future rows.

## Overconfidence review
- Calibrated classifier, uncertainty interval, OOD score and data-quality score are exposed.
- Low data quality/OOD reduces confidence.

## Judge challenge
The strongest challenge remains representativeness. The prototype is honest about this: it demonstrates a defensible engineering architecture and measurable synthetic validation, not operational readiness.
