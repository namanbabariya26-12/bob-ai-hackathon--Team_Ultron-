# Judge Attack Points — Evidence-Based Answers

**Where is the innovation?** Evidence chain + sensor-health/component-health disambiguation + OOD gating + uncertainty + transparent readiness decomposition + reproducible demo.

**Why not thresholds?** Thresholds are a baseline. The system can retain a simpler model if it wins on validation; ML is not assumed superior.

**How do you know the prediction is correct?** You do not know with certainty. The system reports validation metrics, calibrated risk, uncertainty, OOD and data-quality coverage. It explicitly says when evidence is insufficient.

**What if a sensor fails?** Sensor health is checked before interpreting component degradation. Flatlines, spikes, range violations and irregular sampling are surfaced.

**Where did the data come from?** The demo is deterministic synthetic data. NASA C-MAPSS/IMS and PRONOSTIA are documented external research sources, not claimed as local ground truth.

**How is leakage prevented?** Labels are excluded, asset identifiers are removed, and an ordered holdout is used. Production expansion should add automated asset-wise and temporal leakage tests.

**Can the LLM explain every prediction?** The architecture keeps the LLM outside the numerical prediction path. The evidence object is authoritative; narration cannot create sensor facts.

**Is it deployment ready?** No. It is a hackathon prototype with a documented path to field validation.
