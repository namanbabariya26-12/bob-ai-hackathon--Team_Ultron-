# Research Evidence Ledger

| Claim | Source | Evidence strength | India relevance | Limitation | Used in system? |
|---|---|---|---|---|---|
| NASA maintains a public prognostics repository containing run-to-failure and condition-monitoring datasets, including IMS bearings and C-MAPSS-derived datasets. | NASA Prognostics Center of Excellence Data Set Repository | Strong, primary repository | Indirect | Research/lab/simulation data; not Indian operational ground truth | Yes, dataset strategy |
| C-MAPSS Jet Engine Simulated Data contains multivariate engine time series, operating settings, sensor noise, run-to-failure training trajectories and truncated test trajectories for RUL prediction. | NASA Open Data Portal, CMAPSS Jet Engine Simulated Data | Strong, primary repository | Indirect | Simulated turbofan domain | Yes, RUL research basis |
| IMS Bearings is a public NASA data entry for bearing experiments supplied by the University of Cincinnati IMS. | NASA Open Data Portal | Strong, primary repository | Indirect | Different hardware/conditions from intended deployment | Research reference |
| PRONOSTIA is an experimental platform designed for bearing fault detection, diagnosis and prognostics over degradation to failure. | FEMTO-ST / original PRONOSTIA publication | Strong, original technical source | Indirect | Accelerated bearing experiments | Research reference |
| The prototype must not infer Indian operational validity from foreign datasets. | Engineering inference from domain-shift analysis | Medium | High | Requires local validation | Yes |

## Source links

- NASA PCoE repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/
- NASA C-MAPSS Jet Engine Simulated Data: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- NASA IMS Bearings: https://data.nasa.gov/dataset/activity/ims-bearings
- PRONOSTIA original publication: https://publiweb.femto-st.fr/tntnet/entries/1528/documents/author/data
