# Hugging Face Strategy

Hugging Face is intentionally optional in the MVP. The numerical prediction path is deterministic scikit-learn code so the demo remains reproducible without an external model service.

Potential future uses:
- time-series foundation models for representation learning,
- transformer encoders for long maintenance histories,
- NLP models for maintenance-note normalization.

Gate for adoption:
1. Verify model license and version.
2. Benchmark against the current baseline.
3. Test domain shift and OOD behavior.
4. Measure inference latency and memory.
5. Keep the model off the critical path until reproducibility is demonstrated.

No Hugging Face model is claimed as a source of maintenance truth.
