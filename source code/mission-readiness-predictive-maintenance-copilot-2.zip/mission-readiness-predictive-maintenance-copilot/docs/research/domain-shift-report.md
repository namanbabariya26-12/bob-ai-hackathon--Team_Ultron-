# Domain Shift Report

## Purpose

Public datasets are used as research/benchmark evidence only. They are not treated as Indian operational ground truth.

## C-MAPSS

- Domain: simulated commercial turbofan engines.
- Strength: multivariate time series, operating settings, sensor noise and run-to-failure RUL structure.
- Transfer risks: simulated physics, commercial engine configuration, sensor placement, environmental regime, maintenance policy and failure mechanisms differ from any target fleet.
- Required adaptation: collect representative local data; align sensor semantics/ranges; validate operating-regime coverage; asset-wise/time-aware holdout; calibrate thresholds and uncertainty.

## IMS Bearings

- Domain: laboratory bearing experiments.
- Strength: vibration-oriented degradation and run-to-failure trajectories.
- Transfer risks: laboratory loading, bearing configuration, sampling and fault evolution differ from field assets.
- Required adaptation: compare vibration spectra, load profiles, sensor mounting and failure labels against local equipment.

## PRONOSTIA/FEMTO-ST

- Domain: accelerated bearing degradation experiments.
- Strength: full degradation trajectories and prognostic research value.
- Transfer risks: accelerated-life conditions and hardware-specific degradation mechanisms.
- Required adaptation: field validation and recalibration.

## Climate and geography

Foreign datasets do not encode Indian climate/maintenance practice by default. Temperature, dust, humidity, maintenance intervals, component suppliers, operator behavior and configuration management can shift distributions.

## Deployment gate

No operational prediction claim should be made until representative local validation demonstrates acceptable discrimination, calibration, false-positive/false-negative behavior, sensor-fault handling and OOD performance.
