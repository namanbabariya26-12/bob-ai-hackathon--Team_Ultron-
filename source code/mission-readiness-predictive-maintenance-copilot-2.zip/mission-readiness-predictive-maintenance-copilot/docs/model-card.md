# Model Card — Demo Candidate

## Models

1. Calibrated Random Forest classifier for short-horizon failure risk.
2. Random Forest regressor for RUL estimate.
3. Isolation Forest for anomaly screening.
4. Mahalanobis-style feature-space OOD score.
5. Residual-quantile uncertainty interval for RUL.

## Training data

Deterministic synthetic run-to-failure-inspired trajectories generated with seed 42. Public NASA datasets are not silently bundled as ground truth.

## Features

temperature, vibration_rms, pressure, rpm, load, trend features, pressure deviation, cycles since maintenance.

## Validation

Ordered 80/20 holdout with independent synthetic asset trajectories. Leakage-sensitive features are excluded from model inputs.

## Intended use

Competition demonstration of an evidence-first predictive-maintenance architecture.

## Not intended for

Operational maintenance authorization, safety certification, tactical decisions, weapons systems, or any use requiring validated field performance.

## Failure modes

Sparse history, unseen regimes, sensor malfunction, configuration changes, domain shift and incorrect maintenance records can degrade performance.

## OOD behavior

Higher OOD score lowers confidence and should trigger data-quality review rather than high-confidence prediction.

## Version

1.0.0 / 2026-09-14 demo build.
