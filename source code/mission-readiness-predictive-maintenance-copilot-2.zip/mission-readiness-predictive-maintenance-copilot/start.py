"""Cross-platform launcher for the Mission Readiness Copilot.

Run with:
    python start.py

This launcher does not create or require any batch/shell script. It starts
Uvicorn using the current Python environment and opens the local dashboard.
"""
from __future__ import annotations

import os
import sys
import threading
import webbrowser


def main() -> None:
    try:
        import uvicorn
    except ImportError:
        print("Dependencies are not installed. Run: python -m pip install -r requirements.txt")
        raise SystemExit(1)

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    url = f"http://{host}:{port}"

    print("Mission Readiness & Predictive Maintenance Copilot")
    print(f"Starting server at {url}")
    print("Press Ctrl+C to stop.")

    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    uvicorn.run("app.main:app", host=host, port=port, reload=False)


if __name__ == "__main__":
    main()
