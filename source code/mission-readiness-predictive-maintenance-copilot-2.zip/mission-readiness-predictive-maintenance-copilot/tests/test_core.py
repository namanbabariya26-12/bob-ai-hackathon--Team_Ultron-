import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app.main as m

def setup_module():
    m.init_db(); m.seed_demo(force=True); m.train_models()

def test_assets_and_health():
    a=m.assets(); assert len(a)==3
    h=m.asset_health('ASSET-002'); assert 0 <= h['readiness'] <= 100
    assert h['type']=='DERIVED'

def test_predictions_have_evidence_and_uncertainty():
    r=m.get_prediction('ASSET-002'); assert r['predictions']
    p=r['predictions'][0]
    for k in ['risk_pct','confidence','rul_interval','ood_score','data_quality_score','evidence','model_version','is_synthetic']:
        assert k in p
    assert p['is_synthetic'] is True

def test_whatif_changes_scenario():
    p=m.get_prediction('ASSET-002')['predictions'][0]
    base=p['risk_pct']; delayed=min(99,max(1,base*(1+0.035*7)))
    assert delayed >= base

def test_sensor_health_detects_demo_anomaly():
    h=m.sensor_health('ASSET-002')
    assert isinstance(h['score'],int)

def test_no_future_label_feature():
    assert 'rul' not in m.FEATURES and 'failure_soon' not in m.FEATURES


def test_dynamic_maintenance_status_is_not_hardcoded():
    h=m.asset_health('ASSET-001')
    assert 'days_since_maintenance' in h['decomposition']
    assert 25 <= h['decomposition']['maintenance_status'] <= 100

def test_bob_status_shape():
    s=m.bob_status()
    assert {'configured','api_key_present','base_url','model','transport','cli_required','reachable'} <= set(s)
    assert s['cli_required'] is False
    assert s['transport'] == 'HTTPS REST API'

def test_batch_ingest_schema():
    b=m.BatchIngest(readings=[m.IngestReading(sensor_id='ASSET-001-C1-temperature', ts='2026-09-15T10:00:00Z', value=75)])
    assert len(b.readings)==1
