from __future__ import annotations

import hashlib
import json
import math
import os
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from sklearn.ensemble import IsolationForest, RandomForestClassifier, RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.preprocessing import StandardScaler
from sklearn.calibration import CalibratedClassifierCV

try:
    import shap
except Exception:
    shap = None

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
REPORTS = ROOT / "reports" / "generated"
MODELS = ROOT / "models"
STATIC = ROOT / "static"
DB_PATH = DATA / "copilot.db"
load_dotenv(ROOT / ".env")
DATA.mkdir(exist_ok=True)
REPORTS.mkdir(parents=True, exist_ok=True)
MODELS.mkdir(exist_ok=True)

SYNTHETIC = True
RNG_SEED = 42
APP_VERSION = "2.0.0"
BOB_API_KEY = os.getenv("BOB_API_KEY", "").strip()
BOB_BASE_URL = os.getenv("BOB_BASE_URL", "https://api.us-east.bob.ibm.com/inference/v1").rstrip("/")
BOB_MODEL = os.getenv("BOB_MODEL", "premium").strip() or "premium"
BOB_AUTH_SCHEME = os.getenv("BOB_AUTH_SCHEME", "Apikey").strip() or "Apikey"
BOB_INSTANCE_ID = os.getenv("BOB_INSTANCE_ID", "").strip()
BOB_TEAM_ID = os.getenv("BOB_TEAM_ID", "").strip()
BOB_TIMEOUT_SECONDS = float(os.getenv("BOB_TIMEOUT_SECONDS", "90"))
BOB_MAX_TOKENS = int(os.getenv("BOB_MAX_TOKENS", "2048"))
BOB_USER_AGENT = os.getenv("BOB_USER_AGENT", "mission-readiness-copilot/3.0")
FEATURES = [
    "temperature",
    "vibration_rms",
    "pressure",
    "rpm",
    "load",
    "temp_trend",
    "vibration_trend",
    "pressure_dev",
    "cycles_since_maintenance",
    "degradation_index",
]

app = FastAPI(title="Mission Readiness & Predictive Maintenance Copilot", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db() as c:
        c.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS assets (
              id TEXT PRIMARY KEY, fleet_id TEXT, type TEXT, serial TEXT,
              commissioned_at TEXT, metadata_json TEXT
            );
            CREATE TABLE IF NOT EXISTS components (
              id TEXT PRIMARY KEY, asset_id TEXT, subsystem TEXT, name TEXT,
              criticality REAL, install_date TEXT, life_limit_h REAL
            );
            CREATE TABLE IF NOT EXISTS sensors (
              id TEXT PRIMARY KEY, component_id TEXT, name TEXT, unit TEXT,
              sample_rate_hz REAL, range_min REAL, range_max REAL, is_active INTEGER
            );
            CREATE TABLE IF NOT EXISTS sensor_readings (
              id INTEGER PRIMARY KEY AUTOINCREMENT, sensor_id TEXT, ts TEXT,
              value REAL, quality_flag TEXT
            );
            CREATE TABLE IF NOT EXISTS maintenance_events (
              id TEXT PRIMARY KEY, asset_id TEXT, component_id TEXT, type TEXT,
              performed_at TEXT, technician TEXT, notes_raw TEXT, notes_structured_json TEXT
            );
            CREATE TABLE IF NOT EXISTS predictions (
              id TEXT PRIMARY KEY, asset_id TEXT, component_id TEXT, model_run_id TEXT,
              horizon_h INTEGER, risk_pct REAL, confidence TEXT, interval_lo REAL,
              interval_hi REAL, rul REAL, ood_score REAL, dq_score REAL,
              prediction_type TEXT, evidence_json TEXT, created_at TEXT, is_synthetic INTEGER
            );
            CREATE TABLE IF NOT EXISTS model_runs (
              id TEXT PRIMARY KEY, model_name TEXT, model_version TEXT, dataset_version TEXT,
              feature_pipeline_v TEXT, trained_at TEXT, metrics_json TEXT, status TEXT
            );
            CREATE TABLE IF NOT EXISTS datasets (
              id TEXT PRIMARY KEY, name TEXT, source TEXT, source_url TEXT, license TEXT,
              is_synthetic INTEGER, collection_date TEXT, domain TEXT, provenance_json TEXT
            );
            CREATE TABLE IF NOT EXISTS audit_logs (
              id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, action TEXT,
              entity_type TEXT, entity_id TEXT, model_run_id TEXT, prediction_id TEXT,
              ts TEXT, ip_hash TEXT
            );
            CREATE TABLE IF NOT EXISTS alerts (
              id TEXT PRIMARY KEY, prediction_id TEXT, component_id TEXT, severity TEXT,
              type TEXT, message TEXT, created_at TEXT
            );
            """
        )


def now():
    return datetime.now(timezone.utc).isoformat()


def audit(action: str, entity_type: str, entity_id: str = "", model_run_id: str = "", prediction_id: str = ""):
    with db() as c:
        c.execute(
            "INSERT INTO audit_logs(user_id,action,entity_type,entity_id,model_run_id,prediction_id,ts,ip_hash) VALUES(?,?,?,?,?,?,?,?)",
            ("demo-user", action, entity_type, entity_id, model_run_id, prediction_id, now(), "demo"),
        )


def seed_demo(force: bool = False):
    with db() as c:
        count = c.execute("SELECT COUNT(*) n FROM assets").fetchone()["n"]
    if count and not force:
        return
    if force:
        with db() as c:
            for t in ["sensor_readings", "sensors", "components", "maintenance_events", "predictions", "alerts", "assets", "model_runs", "datasets"]:
                c.execute(f"DELETE FROM {t}")

    rng = np.random.default_rng(RNG_SEED)
    base = datetime.now(timezone.utc) - timedelta(days=90)
    assets = []
    components = []
    sensors = []
    readings = []
    maint = []
    sensor_defs = {
        "temperature": ("C", 0, 140),
        "vibration_rms": ("g", 0, 5),
        "pressure": ("kPa", 70, 150),
        "rpm": ("rpm", 500, 4000),
        "load": ("%", 0, 110),
    }
    for ai in range(1, 4):
        aid = f"ASSET-{ai:03d}"
        assets.append((aid, "FLEET-DEMO", "maintenance-demo-asset", f"SN-{1000+ai}", base.isoformat(), json.dumps({"synthetic": True})))
        for ci, subsystem in enumerate(["Drive", "Cooling", "Power", "Control"], 1):
            cid = f"{aid}-C{ci}"
            criticality = [0.95, 0.75, 0.9, 0.6][ci - 1]
            components.append((cid, aid, subsystem, f"{subsystem} Assembly", criticality, base.isoformat(), 2500))
            for sname, (unit, rmin, rmax) in sensor_defs.items():
                sid = f"{cid}-{sname}"
                sensors.append((sid, cid, sname, unit, 1 / 3600, rmin, rmax, 1))
                n = 180
                degrade = (ai == 2 and ci == 1)
                for cycle in range(n):
                    ts = base + timedelta(hours=12 * cycle)
                    phase = cycle / (n - 1)
                    d = max(0, (phase - 0.48) / 0.52) if degrade else 0.08 * phase
                    if sname == "temperature": val = 72 + 3 * np.sin(cycle / 9) + 18 * d + rng.normal(0, 1.1)
                    elif sname == "vibration_rms": val = 0.8 + 0.12 * np.sin(cycle / 7) + 1.9 * d**1.7 + rng.normal(0, 0.08)
                    elif sname == "pressure": val = 108 - 2.5 * d + rng.normal(0, 1.2)
                    elif sname == "rpm": val = 2200 + 70 * np.sin(cycle / 5) + rng.normal(0, 18)
                    else: val = 58 + 8 * np.sin(cycle / 11) + 7 * d + rng.normal(0, 2)
                    quality = "GOOD"
                    if degrade and sname == "temperature" and cycle in (132, 133):
                        val = 132; quality = "RANGE_SUSPECT"
                    if degrade and sname == "vibration_rms" and cycle in (145, 146, 147):
                        val = 4.8; quality = "SPIKE_SUSPECT"
                    readings.append((sid, ts.isoformat(), float(val), quality))
            if ci == 1:
                mdate = base + timedelta(days=32)
                maint.append((str(uuid.uuid4()), aid, cid, "PREVENTIVE", mdate.isoformat(), "DEMO-TECH", "Vibration inspected; coupling lubricated; no confirmed failure.", json.dumps({"component":"Drive Assembly","symptom":"vibration inspected","severity":"uncertain"})))

    with db() as c:
        c.executemany("INSERT OR REPLACE INTO assets VALUES(?,?,?,?,?,?)", assets)
        c.executemany("INSERT OR REPLACE INTO components VALUES(?,?,?,?,?,?,?)", components)
        c.executemany("INSERT OR REPLACE INTO sensors VALUES(?,?,?,?,?,?,?,?)", sensors)
        c.executemany("INSERT INTO sensor_readings(sensor_id,ts,value,quality_flag) VALUES(?,?,?,?)", readings)
        c.executemany("INSERT OR REPLACE INTO maintenance_events VALUES(?,?,?,?,?,?,?,?)", maint)
        c.execute("INSERT OR REPLACE INTO datasets VALUES(?,?,?,?,?,?,?,?,?)", (
            "DEMO-SYN-001", "Synthetic fleet health demo", "Local deterministic generator", "N/A", "Synthetic demonstration data", 1, now(), "Industrial-maintenance-inspired", json.dumps({"seed":RNG_SEED,"limitations":"Synthetic; not operational data"})
        ))
    audit("DEMO_SEED", "dataset", "DEMO-SYN-001")


def load_asset_series(asset_id: str) -> pd.DataFrame:
    q = """
    SELECT a.id asset_id, c.id component_id, s.name sensor, r.ts, r.value, r.quality_flag
    FROM assets a JOIN components c ON c.asset_id=a.id JOIN sensors s ON s.component_id=c.id
    JOIN sensor_readings r ON r.sensor_id=s.id WHERE a.id=? ORDER BY r.ts
    """
    with db() as c:
        rows = c.execute(q, (asset_id,)).fetchall()
    df = pd.DataFrame([dict(x) for x in rows])
    if df.empty: return df
    df["ts"] = pd.to_datetime(df["ts"], utc=True)
    return df


def feature_frame(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty: return df
    p = df.pivot_table(index=["asset_id","component_id","ts"], columns="sensor", values="value", aggfunc="mean").reset_index()
    for col in ["temperature","vibration_rms","pressure","rpm","load"]:
        if col not in p: p[col] = np.nan
    p = p.sort_values(["asset_id","component_id","ts"])
    g = p.groupby(["asset_id","component_id"], group_keys=False)
    p["temp_trend"] = g["temperature"].transform(lambda x: x.rolling(12, min_periods=3).mean().diff(3))
    p["vibration_trend"] = g["vibration_rms"].transform(lambda x: x.rolling(12, min_periods=3).mean().diff(3))
    p["pressure_dev"] = (p["pressure"] - 108).abs()
    p["cycles_since_maintenance"] = g.cumcount() - 64
    p["cycles_since_maintenance"] = p["cycles_since_maintenance"].clip(lower=0)
    p["degradation_index"] = ((p["temperature"]-70)/20).clip(lower=0) + ((p["vibration_rms"]-0.75)/2.3).clip(lower=0) + (p["pressure_dev"]/5)
    p = p.replace([np.inf,-np.inf], np.nan).ffill().fillna(0)
    return p


def make_training_data() -> tuple[pd.DataFrame, pd.Series, pd.Series]:
    """Build a larger synthetic training corpus with 12 independent assets."""
    rng = np.random.default_rng(RNG_SEED)
    rows = []
    for aid in range(1, 13):
        fail_cycle = int(rng.integers(120, 210))
        degradation = rng.uniform(0.7, 1.3)
        for cycle in range(fail_cycle):
            phase = cycle / fail_cycle
            d = max(0, (phase - 0.45) / 0.55) ** 1.5
            temp = 70 + 20 * degradation * d + rng.normal(0, 1.4)
            vib = 0.75 + 2.3 * degradation * d + rng.normal(0, 0.10)
            pressure = 108 - 5 * degradation * d + rng.normal(0, 1.4)
            rpm = 2200 + rng.normal(0, 25)
            load = 60 + 8 * d + rng.normal(0, 2.5)
            temp_trend = 20 * degradation * max(0, d - 0.2) / max(1, cycle/20)
            vib_trend = 2.3 * degradation * max(0, d - 0.2) / max(1, cycle/20)
            pressure_dev = abs(pressure - 108)
            csm = max(0, cycle - 50)
            degradation_index=max(0,(temp-70)/20)+max(0,(vib-0.75)/2.3)+pressure_dev/5
            rows.append([temp,vib,pressure,rpm,load,temp_trend,vib_trend,pressure_dev,csm,degradation_index,fail_cycle-cycle, int(d > 0.55), aid])
    cols = FEATURES + ["rul","failure_soon","asset_num"]
    x = pd.DataFrame(rows, columns=cols)
    # Explicitly prevent leakage: asset_num and RUL are removed before training.
    y_rul = x.pop("rul")
    y_cls = x.pop("failure_soon")
    x = x.drop(columns=["asset_num"])
    return x, y_cls, y_rul


MODELS_STATE: dict[str, Any] = {}
METRICS: dict[str, Any] = {}


def train_models():
    global MODELS_STATE, METRICS
    X, y_cls, y_rul = make_training_data()
    # Time-like split is simulated by keeping the last 20% of generated observations out of training.
    cut = int(len(X) * 0.8)
    Xtr, Xte = X.iloc[:cut], X.iloc[cut:]
    yctr, ycte = y_cls.iloc[:cut], y_cls.iloc[cut:]
    yrtr, yrte = y_rul.iloc[:cut], y_rul.iloc[cut:]
    clf_base = RandomForestClassifier(n_estimators=220, max_depth=9, min_samples_leaf=4, random_state=RNG_SEED, class_weight="balanced")
    clf = CalibratedClassifierCV(clf_base, method="sigmoid", cv=3)
    clf.fit(Xtr, yctr)
    pred = clf.predict(Xte); prob = clf.predict_proba(Xte)[:,1]
    rf = RandomForestRegressor(n_estimators=240, max_depth=12, min_samples_leaf=3, random_state=RNG_SEED)
    rf.fit(Xtr, yrtr)
    pr = np.maximum(0, rf.predict(Xte))
    residual = np.abs(yrte.to_numpy() - pr)
    q = float(np.quantile(residual, 0.90))
    # anomaly baseline + isolation forest
    scaler = StandardScaler().fit(Xtr)
    iso = IsolationForest(n_estimators=180, contamination=0.08, random_state=RNG_SEED)
    iso.fit(scaler.transform(Xtr))
    anomaly = iso.predict(scaler.transform(Xte)) == -1
    # pseudo anomaly ground truth: high degradation proxy using failure label
    anomaly_f1 = f1_score(ycte, anomaly.astype(int), zero_division=0)
    METRICS = {
        "classification": {
            "precision": float(precision_score(ycte, pred, zero_division=0)),
            "recall": float(recall_score(ycte, pred, zero_division=0)),
            "f1": float(f1_score(ycte, pred, zero_division=0)),
            "roc_auc": float(roc_auc_score(ycte, prob)),
            "pr_auc": float(average_precision_score(ycte, prob)),
        },
        "rul": {
            "mae": float(mean_absolute_error(yrte, pr)),
            "rmse": float(mean_squared_error(yrte, pr) ** 0.5),
            "p90_abs_residual": q,
            "interval_coverage_90": float(np.mean((yrte.to_numpy() >= np.maximum(0, pr-q)) & (yrte.to_numpy() <= pr+q))),
        },
        "anomaly": {"isolation_forest_f1_vs_failure_proxy": float(anomaly_f1)},
        "validation": {"split": "ordered 80/20 holdout; generated assets are independent; no future features used"},
    }
    MODELS_STATE = {"classifier": clf, "rul": rf, "scaler": scaler, "iso": iso, "rul_q90": q, "train_mean": Xtr.mean().to_numpy(), "train_cov_inv": np.linalg.pinv(np.cov(Xtr.to_numpy(), rowvar=False)), "feature_names": list(X.columns)}
    runid = "RUN-" + uuid.uuid4().hex[:10]
    with db() as c:
        c.execute("INSERT OR REPLACE INTO model_runs VALUES(?,?,?,?,?,?,?,?)", (runid,"RF-classifier+RF-RUL+IsolationForest",APP_VERSION,"SYNTHETIC-42","features-v1",now(),json.dumps(METRICS),"validated-demo"))
    audit("MODEL_TRAIN", "model_run", runid, runid)
    (REPORTS / "metrics.json").write_text(json.dumps(METRICS, indent=2))
    return runid


def sensor_health(asset_id: str) -> dict:
    df = load_asset_series(asset_id)
    if df.empty: return {"score":0,"issues":["No sensor history"],"sensors":{}}
    out = {}
    for (component_id, sensor), g in df.groupby(["component_id", "sensor"]):
        vals = g.sort_values("ts")["value"].to_numpy()
        issues=[]
        if len(vals) < 10: issues.append("INSUFFICIENT_HISTORY")
        if np.nanstd(vals) < 1e-8: issues.append("FLATLINE")
        med = np.nanmedian(vals); mad = np.nanmedian(np.abs(vals-med)) + 1e-6
        if np.any(np.abs(vals-med) > 8*1.4826*mad): issues.append("SPIKE")
        if sensor=="temperature" and (np.nanmin(vals)<0 or np.nanmax(vals)>140): issues.append("OUT_OF_RANGE")
        if sensor=="vibration_rms" and (np.nanmin(vals)<0 or np.nanmax(vals)>5): issues.append("OUT_OF_RANGE")
        if sensor=="pressure" and (np.nanmin(vals)<70 or np.nanmax(vals)>150): issues.append("OUT_OF_RANGE")
        diffs = np.diff(pd.to_datetime(g.sort_values("ts")["ts"]).astype("int64")/1e9)
        if len(diffs) and np.std(diffs) > max(1, np.mean(diffs)*0.15): issues.append("SAMPLING_IRREGULARITY")
        if len(vals)>30:
            first,last=np.mean(vals[:10]),np.mean(vals[-10:])
            if abs(last-first) > 4*np.nanstd(vals): issues.append("DRIFT")
        key=f"{component_id}:{sensor}"
        out[key]={"issues":sorted(set(issues)),"n":int(len(vals))}
    bad=sum(bool(v["issues"]) for v in out.values())
    score=max(0,100-int(100*bad/max(1,len(out))*0.55))
    return {"score":score,"issues":[f"{s}: {i}" for s,v in out.items() for i in v["issues"]],"sensors":out}


def ood_score(x: np.ndarray) -> float:
    m=MODELS_STATE["train_mean"]; ci=MODELS_STATE["train_cov_inv"]
    d=float(np.sqrt(max(0,(x-m) @ ci @ (x-m))))
    return float(min(1, d/12))


def explain(xdf: pd.DataFrame, model, target_prob: float) -> list[dict]:
    vals = xdf.iloc[0]
    try:
        if shap is not None and hasattr(model, "calibrated_classifiers_"):
            # CalibratedClassifierCV does not expose a stable TreeExplainer API across versions.
            raise RuntimeError("calibrated wrapper")
    except Exception:
        pass
    # Robust model-agnostic local permutation explanation.
    base = target_prob
    rows=[]
    for f in FEATURES:
        z=xdf.copy(); z[f]=MODELS_STATE["train_mean"][FEATURES.index(f)]
        p=float(model.predict_proba(z)[:,1][0])
        rows.append({"feature":f,"value":float(vals[f]),"contribution":float(base-p)})
    rows.sort(key=lambda r: abs(r["contribution"]), reverse=True)
    return rows[:5]


def get_prediction(asset_id: str, horizon_h: int = 336) -> dict:
    if not MODELS_STATE: train_models()
    raw=load_asset_series(asset_id)
    if raw.empty: raise HTTPException(404,"Asset not found")
    f=feature_frame(raw)
    latest=f.sort_values("ts").groupby("component_id").tail(1)
    # The primary demo component is the most critical component; predictions are generated per component.
    comps=[]
    with db() as c:
        rows=c.execute("SELECT id,name,criticality FROM components WHERE asset_id=?",(asset_id,)).fetchall()
    for comp in rows:
        row=latest[latest.component_id==comp["id"]]
        if row.empty: continue
        x=row[FEATURES].astype(float)
        p=float(MODELS_STATE["classifier"].predict_proba(x)[:,1][0])
        rul=max(0,float(MODELS_STATE["rul"].predict(x)[0]))
        q=MODELS_STATE["rul_q90"]
        ood=ood_score(x.iloc[0].to_numpy())
        sh=sensor_health(asset_id)
        dq=float(sh["score"])/100
        if ood>0.75 or dq<0.55:
            confidence="Low"
        elif ood>0.45 or dq<0.75:
            confidence="Medium"
        else:
            confidence="High"
        evidence=explain(x, MODELS_STATE["classifier"], p)
        if confidence=="Low": p=min(p,0.65)
        pred={
            "asset_id":asset_id,"component_id":comp["id"],"component_name":comp["name"],
            "horizon_h":horizon_h,"risk_pct":round(p*100,1),"confidence":confidence,
            "rul_hours":round(rul,1),"rul_interval":[round(max(0,rul-q),1),round(rul+q,1)],
            "ood_score":round(ood,3),"data_quality_score":round(dq,3),
            "prediction_type":"PREDICTED","is_synthetic":True,"model_version":APP_VERSION,
            "evidence":evidence,"known_limitations":["Synthetic demonstration data","No local operational validation","Model estimate, not confirmed failure"],
            "data_timestamp":str(row.ts.iloc[0]),"missing_information":sh["issues"][:8]
        }
        comps.append(pred)
    return {"asset_id":asset_id,"predictions":comps,"sensor_health":sensor_health(asset_id)}


class IngestReading(BaseModel):
    sensor_id: str
    ts: str
    value: float
    quality_flag: str = "UNVERIFIED"

class CopilotChat(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    asset_id: str | None = None

class BatchIngest(BaseModel):
    readings: list[IngestReading] = Field(min_length=1, max_length=5000)

def _bob_headers() -> dict[str, str]:
    headers = {
        "Authorization": f"{BOB_AUTH_SCHEME} {BOB_API_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": BOB_USER_AGENT,
    }
    if BOB_INSTANCE_ID:
        headers["x-instance-id"] = BOB_INSTANCE_ID
    if BOB_TEAM_ID:
        headers["x-team-id"] = BOB_TEAM_ID
    return headers


def _bob_model_info() -> dict:
    """Read Bob's current model catalog directly over HTTPS; no Bob CLI required."""
    import httpx
    if not BOB_API_KEY:
        return {"ok": False, "error": "BOB_API_KEY is missing"}
    try:
        with httpx.Client(timeout=min(10.0, BOB_TIMEOUT_SECONDS)) as client:
            response = client.get(f"{BOB_BASE_URL}/model/info", headers=_bob_headers())
        if response.status_code >= 400:
            detail = response.text[:1000]
            return {"ok": False, "status_code": response.status_code, "error": detail}
        data = response.json()
        return {"ok": True, "data": data}
    except httpx.TimeoutException:
        return {"ok": False, "error": "IBM Bob model-info request timed out"}
    except Exception as exc:
        return {"ok": False, "error": f"IBM Bob model-info request failed: {exc}"}


def _extract_models(model_info: dict) -> list[str]:
    data = model_info.get("data", {}) if isinstance(model_info, dict) else {}
    candidates = data.get("models", data.get("data", data if isinstance(data, list) else []))
    if isinstance(candidates, dict):
        candidates = candidates.get("models", [])
    models: list[str] = []
    if isinstance(candidates, list):
        for item in candidates:
            if isinstance(item, str):
                models.append(item)
            elif isinstance(item, dict):
                if item.get("exposed", True) is False:
                    continue
                model_id = item.get("id") or item.get("model") or item.get("name") or item.get("route")
                if model_id:
                    models.append(str(model_id))
    return list(dict.fromkeys(models))


def bob_status() -> dict:
    key_present = bool(BOB_API_KEY)
    configured = key_present and bool(BOB_BASE_URL)
    status = {
        "configured": configured,
        "api_key_present": key_present,
        "api_type": "Inference" if key_present else "not configured",
        "base_url": BOB_BASE_URL,
        "model": BOB_MODEL,
        "auth_scheme": BOB_AUTH_SCHEME,
        "instance_id_present": bool(BOB_INSTANCE_ID),
        "team_id_present": bool(BOB_TEAM_ID),
        "transport": "HTTPS REST API",
        "cli_required": False,
        "reachable": False,
    }
    if not configured:
        status["error"] = "Set BOB_API_KEY in .env"
        return status
    probe = _bob_model_info()
    status["reachable"] = bool(probe.get("ok"))
    status["models"] = _extract_models(probe)[:20]
    if not probe.get("ok"):
        status["error"] = probe.get("error", "IBM Bob API unavailable")
        status["status_code"] = probe.get("status_code")
    elif BOB_MODEL not in status["models"] and status["models"]:
        status["model_warning"] = f"Configured model '{BOB_MODEL}' was not returned by Bob model discovery"
    return status


def _copilot_context(asset_id: str | None) -> str:
    assets_list = assets()
    selected = asset_id or (assets_list[0]["id"] if assets_list else None)
    context: dict[str, Any] = {"generated_at": now(), "assets": []}
    for a in assets_list[:12]:
        h = asset_health(a["id"])
        context["assets"].append({
            "asset_id": a["id"],
            "readiness": h["readiness"],
            "decomposition": h["decomposition"],
            "predictions": h["predictions"][:4],
            "sensor_health": h["predictions"][0].get("missing_information", []) if h["predictions"] else [],
        })
    if selected:
        with db() as c:
            rows=c.execute("""SELECT s.id sensor_id,s.name,r.ts,r.value,r.quality_flag
                              FROM sensors s JOIN components c ON c.id=s.component_id
                              JOIN sensor_readings r ON r.sensor_id=s.id
                              WHERE c.asset_id=? ORDER BY r.ts DESC LIMIT 40""", (selected,)).fetchall()
        context["selected_asset_recent_readings"]=[dict(r) for r in rows]
    return json.dumps(context, default=str)


def run_bob(message: str, asset_id: str | None = None) -> dict:
    if not BOB_API_KEY:
        return {
            "configured": False,
            "answer": "IBM Bob is not connected. Add BOB_API_KEY to .env and restart the server. No Bob CLI installation is required.",
            "provider": "IBM Bob REST API",
        }

    system = """You are the Mission Readiness & Predictive Maintenance Copilot.
Focus only on equipment health, sensor integrity, reliability, maintenance planning, uncertainty, data quality and engineering inspection.
Never provide weapon targeting, attack planning, tactical optimization, or lethal-action advice.
Use only the supplied telemetry and prediction context. Do not invent measurements, failures, maintenance events, or certainty.
Clearly distinguish observed readings, model estimates, scenarios and missing information.
If evidence is insufficient, say so. Prefer concise, actionable engineering language.
"""
    context = _copilot_context(asset_id)
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": "CURRENT DATA CONTEXT (JSON):\n" + context + "\n\nUSER QUESTION:\n" + message},
    ]
    payload = {
        "model": BOB_MODEL,
        "messages": messages,
        "temperature": 0.2,
        "max_tokens": BOB_MAX_TOKENS,
    }
    import httpx
    try:
        with httpx.Client(timeout=BOB_TIMEOUT_SECONDS) as client:
            response = client.post(f"{BOB_BASE_URL}/chat/completions", headers=_bob_headers(), json=payload)
        if response.status_code >= 400:
            detail = response.text[:2000]
            return {"configured": True, "provider": "IBM Bob REST API", "error": f"IBM Bob API returned HTTP {response.status_code}: {detail}"}
        result = response.json()
        choices = result.get("choices") or []
        if not choices:
            return {"configured": True, "provider": "IBM Bob REST API", "error": "IBM Bob returned no choices."}
        message_obj = choices[0].get("message", {})
        answer = message_obj.get("content", "")
        if isinstance(answer, list):
            answer = "\n".join(str(x.get("text", x)) if isinstance(x, dict) else str(x) for x in answer)
        return {
            "configured": True,
            "provider": "IBM Bob REST API",
            "model": result.get("model", BOB_MODEL),
            "answer": str(answer).strip(),
            "usage": result.get("usage", {}),
            "request_id": response.headers.get("x-request-id") or response.headers.get("request-id"),
        }
    except httpx.TimeoutException:
        return {"configured": True, "provider": "IBM Bob REST API", "error": f"IBM Bob API request timed out after {BOB_TIMEOUT_SECONDS:g} seconds."}
    except Exception as exc:
        return {"configured": True, "provider": "IBM Bob REST API", "error": f"IBM Bob API request failed: {exc}"}

class WhatIf(BaseModel):
    asset_id: str
    component_id: str
    delay_days: int = Field(default=7, ge=0, le=90)
    intervention: str = "delay_maintenance"


def api_key_ok(key: str | None):
    expected=os.getenv("ADMIN_API_KEY","demo-admin-key")
    return key == expected


@app.on_event("startup")
def startup():
    init_db(); seed_demo(); train_models()

@app.get("/")
def root(): return FileResponse(STATIC/"index.html")

@app.get("/api/v1/health")
def health():
    return {"status":"ok","demo_mode":os.getenv("APP_ENV","demo")=="demo","synthetic":True,"version":APP_VERSION,"bob":bob_status()}

@app.get("/api/v1/copilot/status")
def copilot_status():
    return bob_status()

@app.post("/api/v1/copilot/chat")
def copilot_chat(req: CopilotChat):
    result=run_bob(req.message, req.asset_id)
    audit("COPILOT_CHAT", "asset", req.asset_id or "fleet")
    return result

@app.get("/api/v1/live/summary")
def live_summary():
    with db() as c:
        row=c.execute("SELECT MAX(ts) latest_reading, COUNT(*) reading_count FROM sensor_readings").fetchone()
    return {"generated_at":now(),"latest_reading":row["latest_reading"],"reading_count":row["reading_count"],"bob":bob_status()}

@app.get("/api/v1/assets")
def assets():
    with db() as c: rows=c.execute("SELECT * FROM assets ORDER BY id").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/v1/sensors")
def sensors_list():
    with db() as c: rows=c.execute("SELECT s.id,s.component_id,s.name,s.unit,s.range_min,s.range_max,c.asset_id FROM sensors s JOIN components c ON c.id=s.component_id ORDER BY c.asset_id,s.id").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/v1/assets/{asset_id}/health")
def asset_health(asset_id: str):
    pred=get_prediction(asset_id)
    risks=[p["risk_pct"] for p in pred["predictions"]]
    critical=max((p["risk_pct"] for p in pred["predictions"]), default=0)
    sh=pred["sensor_health"]
    comp_health=max(0,100-critical)
    with db() as c:
        maint_count = c.execute("SELECT COUNT(*) n FROM maintenance_events WHERE asset_id=?", (asset_id,)).fetchone()["n"]
        latest_maint = c.execute("SELECT performed_at FROM maintenance_events WHERE asset_id=? ORDER BY performed_at DESC LIMIT 1", (asset_id,)).fetchone()
    if latest_maint:
        try:
            days_since = max(0.0, (datetime.now(timezone.utc) - datetime.fromisoformat(latest_maint["performed_at"].replace("Z", "+00:00"))).total_seconds() / 86400)
        except Exception:
            days_since = 30.0
    else:
        days_since = 30.0
    maintenance_status = max(25.0, min(100.0, 100.0 - min(days_since, 120.0) * 0.45 + min(maint_count, 5) * 2.0))
    readiness=round(0.35*comp_health+0.2*sh["score"]+0.2*(100-critical)+0.15*maintenance_status+0.1*(sum(p["data_quality_score"] for p in pred["predictions"])/max(1,len(pred["predictions"])))*100,1)
    return {"asset_id":asset_id,"readiness":readiness,"decomposition":{"critical_component_health":comp_health,"sensor_health":sh["score"],"predicted_failure_risk":100-critical,"maintenance_status":round(maintenance_status,1),"days_since_maintenance":round(days_since,1),"data_confidence":round(np.mean([p["data_quality_score"] for p in pred["predictions"]])*100,1) if pred["predictions"] else 0},"predictions":pred["predictions"],"type":"DERIVED"}

@app.get("/api/v1/sensors/{sensor_id}/readings")
def sensor_readings(sensor_id: str, limit: int = Query(200, le=1000)):
    with db() as c: rows=c.execute("SELECT ts,value,quality_flag FROM sensor_readings WHERE sensor_id=? ORDER BY ts DESC LIMIT ?",(sensor_id,limit)).fetchall()
    return [dict(r) for r in reversed(rows)]

@app.get("/api/v1/predictions/latest")
def predictions_latest(horizon_h:int=336):
    return [get_prediction(a["id"],horizon_h) for a in assets()]

@app.get("/api/v1/predictions/{asset_id}/explain")
def prediction_explain(asset_id: str):
    r=get_prediction(asset_id)
    for p in r["predictions"]:
        p["evidence_statement"]=f"Risk estimate is supported by the top measured/derived contributors shown below. This is a model estimate for a {p['horizon_h']}-hour horizon, not a confirmed failure."
    return r

@app.get("/api/v1/maintenance/queue")
def maintenance_queue():
    items=[]
    for a in assets():
        r=get_prediction(a["id"])
        for p in r["predictions"]:
            critical=next((x["criticality"] for x in _components(a["id"]) if x["id"]==p["component_id"]),0.5)
            priority=p["risk_pct"]*0.55 + (100-min(p["rul_hours"],100))/100*100*0.25 + critical*100*0.2
            items.append({"priority_score":round(priority,1),"priority":"P1" if priority>=65 else "P2" if priority>=45 else "P3","asset_id":a["id"],"component_id":p["component_id"],"reason":["degradation trend" if p["risk_pct"]>40 else "routine monitoring","predicted risk","RUL estimate","component criticality"],"prediction":p})
    return sorted(items,key=lambda x:x["priority_score"],reverse=True)

def _components(asset_id):
    with db() as c:return [dict(r) for r in c.execute("SELECT * FROM components WHERE asset_id=?",(asset_id,)).fetchall()]

@app.post("/api/v1/whatif")
def whatif(req: WhatIf):
    base=get_prediction(req.asset_id)["predictions"]
    p=next((x for x in base if x["component_id"]==req.component_id),None)
    if not p: raise HTTPException(404,"Component prediction not found")
    # Scenario model: extrapolate risk with a documented bounded logistic-like deterioration.
    r0=p["risk_pct"]; delay=req.delay_days
    if req.intervention=="inspect_now": factor=0.88
    elif req.intervention=="replace_component": factor=0.55
    else: factor=1+0.035*delay
    scenario=min(99,max(1,r0*factor))
    return {"scenario":True,"label":"SCENARIO / MODEL ESTIMATE","asset_id":req.asset_id,"component_id":req.component_id,"baseline_risk_pct":r0,"delay_days":delay,"scenario_risk_pct":round(scenario,1),"assumptions":["Scenario is a bounded model estimate, not an observed future event","Risk extrapolation is not validated against operational maintenance policy"],"recommendation":"Prioritize engineering inspection if the estimated risk and evidence warrant it; do not treat this scenario as a confirmed future failure."}

@app.post("/api/v1/ingest/sensor")
def ingest_sensor(req: IngestReading, x_api_key: str | None = Header(default=None)):
    if not api_key_ok(x_api_key): raise HTTPException(401,"Invalid API key")
    if not math.isfinite(req.value): raise HTTPException(422,"Value must be finite")
    with db() as c:
        s=c.execute("SELECT range_min,range_max FROM sensors WHERE id=?",(req.sensor_id,)).fetchone()
        if not s: raise HTTPException(404,"Sensor not found")
        q="GOOD" if s["range_min"]<=req.value<=s["range_max"] else "RANGE_SUSPECT"
        c.execute("INSERT INTO sensor_readings(sensor_id,ts,value,quality_flag) VALUES(?,?,?,?)",(req.sensor_id,req.ts,req.value,q))
    audit("INGEST_SENSOR","sensor",req.sensor_id)
    return {"accepted":True,"quality_flag":q,"is_synthetic":False,"warning":"This prototype does not authenticate source provenance beyond API key."}

@app.post("/api/v1/ingest/batch")
def ingest_batch(req: BatchIngest, x_api_key: str | None = Header(default=None)):
    if not api_key_ok(x_api_key): raise HTTPException(401,"Invalid API key")
    accepted=0; rejected=[]
    with db() as c:
        for idx, reading in enumerate(req.readings):
            if not math.isfinite(reading.value):
                rejected.append({"index":idx,"reason":"Value must be finite"}); continue
            s=c.execute("SELECT range_min,range_max FROM sensors WHERE id=?",(reading.sensor_id,)).fetchone()
            if not s:
                rejected.append({"index":idx,"reason":"Sensor not found","sensor_id":reading.sensor_id}); continue
            q="GOOD" if s["range_min"]<=reading.value<=s["range_max"] else "RANGE_SUSPECT"
            c.execute("INSERT INTO sensor_readings(sensor_id,ts,value,quality_flag) VALUES(?,?,?,?)",(reading.sensor_id,reading.ts,reading.value,q))
            accepted+=1
    audit("INGEST_BATCH", "sensor", f"{accepted}/{len(req.readings)}")
    return {"accepted":accepted,"rejected":rejected,"is_synthetic":False,"recomputed_on_next_read":True}

@app.get("/api/v1/audit")
def audit_logs():
    with db() as c: rows=c.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/v1/models/registry")
def registry():
    with db() as c: rows=c.execute("SELECT * FROM model_runs ORDER BY trained_at DESC").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/v1/metrics")
def metrics(): return METRICS

@app.get("/api/v1/provenance")
def provenance():
    with db() as c: rows=c.execute("SELECT * FROM datasets").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/v1/data-quality/{asset_id}")
def dq(asset_id:str): return sensor_health(asset_id)

@app.get("/api/v1/maintenance/nlp")
def maintenance_nlp():
    with db() as c: rows=c.execute("SELECT id,notes_raw,notes_structured_json FROM maintenance_events ORDER BY performed_at DESC").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/v1/reports/validation")
def validation_report():
    p=REPORTS/"validation_report.json"
    if p.exists(): return json.loads(p.read_text())
    return {"status":"run scripts/run_demo.py"}
